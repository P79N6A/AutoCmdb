## 旋转魔方

<iframe src="https://faysunshine.com/dist/game/mf.html" width="100%" height="540px" scrolling="no"></iframe>