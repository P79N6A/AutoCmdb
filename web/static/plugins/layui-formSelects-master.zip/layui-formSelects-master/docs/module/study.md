> QQ群

769620939 [点我加群](//shang.qq.com/wpa/qunwpa?idkey=9f9d4de074f2cb4d13afb3f04b874742a5f400eac2c0648fcfd20afb5413fb0a ':target=_blank')

> 作者QQ

707200833

> 微信群

![logo](../public/wx.png ':size=300')