!> 捐赠作者

微信扫一扫

![logo](../public/wx.jpg ':size=300')


---


<div class="card">
	<div class="card-header">
		<img src="public/ju_top.jpg" data-no-zoom width="100%" />
	</div>
	<div class="card-content">
		喜欢你，是因为你点亮了一盏灯。<br>
		而我靠近一看，那里确实是我想去的地方。
	</div>
	<div class="card-footer">
		<img src="public/ju_ce.jpg" data-no-zoom width="100%" />
	</div>
</div>


---


> FormSelects 赞赏者名册

| 赞赏者 | 累计金额 	| 留言 				| 赞赏时间 		|
| ----	| -----	 	| -----				| -------		|
| *		| ¥ 1.00	| layui组件捐助 		| 2018-09-05	|
| D*e	| ¥ 0.01	| 			 		| 2018-08-30	|
| *		| ¥ 0.01	| 			 		| 2018-08-30	|
| *哥	| ¥ 8.88	| 感谢大佬帮助	 	| 2018-08-29	|
| L*N	| ¥ 6.66	| 					| 2018-08-29	|
| *强	| ¥ 66		| 膜拜大佬，谢谢啦 	| 2018-08-23	|
| s*n	| ¥ 100		| layui formSelects | 2018-07-12	|